export const adminFilterableFields = [
  "name",
  "email",
  "searchTerm",
  "contactNumber",
];

export const searchableFields = ["name", "email", "contactNumber"];
